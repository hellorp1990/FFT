#c++ -o outputROI main.cpp image.cpp ipTool.cpp ROI.cpp -lfftw3 -lm
c++ -I/Users/rahulpaul/Downloads/fftw-3.3.4/build/include -g3 -o outputROI main.cpp image.cpp ipTool.cpp ROI.cpp -L/Users/rahulpaul/Downloads/fftw-3.3.4/build/lib -lfftw3 -lm
