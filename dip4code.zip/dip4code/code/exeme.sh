outputROI FFTandIFFT lenna.pgm lenna1.pgm
outputROI Filtering lenna.pgm lennal2.pgm

