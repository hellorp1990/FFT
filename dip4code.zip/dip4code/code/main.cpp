/****************************************************************************/
/*  Project Description: Demo code for Assignment 4				      		*/
/*  Jing Zhang  Nov. 2, 2007                         						*/
/****************************************************************************/


#include <stdio.h>
#include <fftw3.h>
#include "image.h"
#include "ipTool.h"
#include<string>
#define WIDTH  256
#define HEIGHT 256
#include <iostream>
#define MAXLEN 256
using namespace std;
//global varialbles;
//function declaration;

void fft(int rows, int columns,Image &src, Image &magDFT,Image &centered,Image &tgt)
{
    //cout<<"rahul";
     fftw_plan planR, planG, planB;
    fftw_complex *inR, *inG, *inB, *outR, *outG, *outB;

    // allocate input arrays
    inR = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * rows * columns);

    for (int i=0;i<rows;i++) {
        for (int j=0;j<columns;j++) {
        double value =src(i,j);
        inR[j+columns * i][0]=value;
        }
    }


    // allocate output arrays
    outR = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * rows * columns);

    // create plans
    planR = fftw_plan_dft_2d(rows,columns, inR, outR, FFTW_FORWARD, FFTW_ESTIMATE);


    // TODO: assign color-values to input arrays

    // perform FORWARD fft
    fftw_execute(planR);

    for (int i=0;i<rows;i++) {
        for (int j=0;j<columns;j++) {

        double realPart = outR[j+columns *i][0] / (double) (rows*columns);
        double imagPart = outR[j+columns *i][1] / (double) (rows*columns);
        double mag = sqrt((realPart*realPart) + (imagPart *imagPart));

        if(mag>1)
        {
            mag=255;

        }

        else{

            mag=mag*255;
        }
        magDFT(i,j)=(int) mag;
        }
    }
for (int i=rows/2;i<rows;i++) {
        for (int j=columns/2;j<columns;j++) {

int v1 = magDFT(i,j);
int v2= magDFT((i-(rows/2)),(j-(columns/2)));
centered(i,j)=v2;
centered((i-rows/2),j-(columns/2)) =v1;


        }
}

for (int i=rows/2;i<rows;i++) {
        for (int j=0;j<columns/2;j++) {

int v1 = magDFT(i,j);
int v2= magDFT((i-(rows/2)),(j+(columns/2)));
centered(i,j)=v2;
centered((i-rows/2),j+(columns/2)) =v1;


        }
}
    // TODO: calculate output mag/phase

    // free memory
    fftw_destroy_plan(planR);

    fftw_free(inR); fftw_free(outR);
}

void filtering(int rows, int columns,Image &src, Image &tgt)
{
    cout<<"paul";
}
//function body;
int main(int argc, char* argv[]){


int rows;
int columns;
Image src;
 Image magDFT;
 Image centered;
 Image tgt;

 char srcName[250];
 char magDFTName[250];
  char centeredName[250];

  char tgtName[250];

	if (argc<2)
	{
		  fprintf(stderr, "Please tell me the filter's name ^^\n");
		  exit(0);


	}
 std::string arg = argv[1];

    if(arg == "fft") {
            strcpy(srcName,argv[2]);
                strcpy(magDFTName,argv[3]);
    strcpy(centeredName,argv[4]);
    strcpy(tgtName,argv[5]);
    src.read(srcName);

        magDFT.initialize(src.NR,src.NC);
        centered.initialize(src.NR,src.NC);
      tgt.initialize(src.NR,src.NC);
    rows = src.NR;
    columns= src.NC;
        // FORWARD TRANSFORM
        fft(rows, columns,src, magDFT,centered,tgt);
        magDFT.save(magDFTName);
        centered.save(centeredName);

    }
    else if (arg == "filtering"){
        // BACKWARD TRANSFORM
                filtering(rows, columns,src, tgt);

    }


	//fprintf(stderr, "Unknow Filter Name\n");
	return 0;

}
